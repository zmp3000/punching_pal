const express = require("express");
const nodemailer = require("nodemailer");
const bodyParser = require("body-parser");
const multer = require("multer");
const { Pool } = require("pg");
const cors = require("cors");

const upload = multer();
const app = express();
const port = 3000;

// Настройка соединения с базой данных PostgreSQL
const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "test_diplom",
  password: "1133",
  port: 5432,
});

app.use(bodyParser.json());
app.use(express.json()); // Парсим тело запроса в формате JSON
app.use(cors());

app.get("/index2.html", (req, res) => {
  res.sendFile(__dirname + "/index2.html");
});

app.get("/api/filter_rek/:id", async (req, res) => {
  const id = parseInt(req.params.id);

  try {
    const result = await pool.query("SELECT * FROM filter_rek WHERE id = $1", [
      id,
    ]);
    if (result.rowCount === 0) {
      return res.status(404).send({ message: "Not found" });
    }
    res.status(200).send(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: "Internal server error" });
  }
});

app.get("/api2/profile_rek/:id", async (req, res) => {
  const id = parseInt(req.params.id);

  try {
    const result = await pool.query("SELECT * FROM profile_rek WHERE id = $1", [
      id,
    ]);
    if (result.rowCount === 0) {
      return res.status(404).send({ message: "Not found" });
    }
    res.status(200).send(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: "Internal server error" });
  }
});

app.post("/admin", async (req, res) => {
  const { title, description, link, block } = req.body;

  try {
    let id;
    if (block === "1") {
      id = 1;
    } else if (block === "2") {
      id = 2;
    } else {
      return res.status(400).send("Invalid block value");
    }

    // Обновление данных в базе данных
    const updatedResult = await pool.query(
      `UPDATE filter_rek SET title = $1, description = $2, link = $3 WHERE id = $4`,
      [title || "", description || "", link || "", id]
    );

    // Возвращаем обновленные данные
    const updatedData = {
      title: title || "",
      description: description || "",
      link: link || "",
    };
    res.status(200).send(updatedData);
  } catch (error) {
    console.error("Error updating data: ", error);
    res.status(500).send("Internal Server Error");
  }
});

app.post("/admin2", async (req, res) => {
  const { title, description, link, block } = req.body;

  try {
    let id;
    if (block === "1") {
      id = 1;
    } else if (block === "2") {
      id = 2;
    } else {
      return res.status(400).send("Invalid block value");
    }

    // Обновление данных в базе данных
    const updatedResult = await pool.query(
      `UPDATE profile_rek SET title = $1, description = $2, link = $3 WHERE id = $4`,
      [title || "", description || "", link || "", id]
    );

    // Возвращаем обновленные данные
    const updatedData = {
      title: title || "",
      description: description || "",
      link: link || "",
    };
    res.status(200).send(updatedData);
  } catch (error) {
    console.error("Error updating data: ", error);
    res.status(500).send("Internal Server Error");
  }
});

// Обработчик для GET запроса на news
app.get("/news", async (req, res) => {
  const { category } = req.query;
  const apiKey = "cc6cda365d534d32afd2d4bfbdd671fa";

  try {
    const { default: fetch } = await import("node-fetch");
    const url = `https://newsapi.org/v2/top-headlines?category=${category}&apiKey=${apiKey}`;
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
  } catch (error) {
    console.error("Ошибка получения новостей:", error.message);
    res.status(500).json({ error: "Ошибка получения новостей" });
  }
});

// Функция для проверки валидности email
function isValidEmail(email) {
  const regex =
    /^(?!\d+@)[a-zA-Z\d]+([a-zA-Z\d]*[-_.]?[a-zA-Z\d]+)*@gmail\.com$/;
  return regex.test(email);
}

app.post("/signin", async (req, res) => {
  const { email, password, passwordToSend } = req.body;

  // Проверка валидности email
  if (!isValidEmail(email)) {
    return res.status(400).send("Invalid email address");
  }

  try {
    // Проверка наличия email в базе данных
    const result = await pool.query("SELECT * FROM users WHERE email = $1", [
      email,
    ]);
    if (result.rowCount > 0) {
      return res.status(409).send("Email already exists");
    }

    // Добавление данных пользователя (почта и пароль) в базу данных
    const client = await pool.connect();
    await client.query("INSERT INTO users (email, password) VALUES ($1, $2)", [
      email,
      password,
    ]);
    client.release();

    // Отправка письма на указанный email
    const transporter = nodemailer.createTransport({
      service: "Gmail",
      host: "smtp.gmail.com",
      port: 465,
      secure: true,
      auth: {
        user: "andreynuke100@gmail.com",
        pass: "lahw twni qfpm jxla",
      },
    });

    const mailOptions = {
      from: "andreynuke100@gmail.com",
      to: email,
      subject: "Registration Confirmation",
      text: `Thank you for registering! Your password is: ${passwordToSend}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error("Error sending email: ", error);
      } else {
        console.log("Email sent: ", info.response);
      }
    });

    res.status(200).send("Email registered successfully!");
  } catch (error) {
    console.error("Error registering email: ", error);
    res.status(500).send("Internal Server Error");
  }
});

// Обработчик POST запроса на /register
app.post("/profile", async (req, res) => {
  const {
    email,
    password,
    name,
    age,
    weight,
    height,
    martial_arts,
    rank,
    additional_details,
  } = req.body;

  // Проверка валидности email
  if (!isValidEmail(email)) {
    return res.status(400).send("Invalid email address");
  }

  try {
    // Поиск пользователя в базе данных
    const client = await pool.connect();
    const result = await client.query(
      "SELECT * FROM users WHERE email = $1 AND password = $2",
      [email, password]
    );

    if (result.rowCount === 0) {
      // Пользователь не найден, возвращаем ошибку
      client.release();
      return res.status(401).send("Invalid email or password");
    }

    // Обновление данных пользователя в базе данных
    const updatedResult = await client.query(
      "UPDATE users SET name = $1, age = $2, weight = $3, height = $4, martial_arts = $5, rank = $6, additional_details = $7 WHERE email = $8 AND password = $9",
      [
        name || result.rows[0].name,
        age || result.rows[0].age,
        weight || result.rows[0].weight,
        height || result.rows[0].height,
        martial_arts || result.rows[0].martial_arts,
        rank || result.rows[0].rank,
        additional_details || result.rows[0].additional_details,
        email,
        password,
      ]
    );

    // Возвращаем обновленные данные пользователя
    const updatedUser = {
      email: result.rows[0].email,
      name: name || result.rows[0].name,
      age: age || result.rows[0].age,
      weight: weight || result.rows[0].weight,
      height: height || result.rows[0].height,
      martial_arts: martial_arts || result.rows[0].martial_arts,
      rank: rank || result.rows[0].rank,
      additional_details:
        additional_details || result.rows[0].additional_details,
    };
    client.release();
    res.status(200).send(updatedUser);
  } catch (error) {
    console.error("Error updating user: ", error);
    res.status(500).send("Internal Server Error");
  }
});

app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  // Проверка валидности email
  if (!isValidEmail(email)) {
    return res.status(400).send("Invalid email address");
  }

  try {
    // Проверка email и пароля в базе данных
    const client = await pool.connect();
    const result = await client.query(
      "SELECT * FROM users WHERE email = $1 AND password = $2",
      [email, password]
    );
    client.release();

    if (result.rowCount === 1) {
      // Авторизация успешна
      console.log("User logged in:", email);
      res.status(200).send("Login successful!");
    } else {
      // Авторизация не удалась
      console.log("Invalid email or password for user:", email);
      res.status(401).send("Invalid email or password");
    }
  } catch (error) {
    console.error("Error logging in: ", error);
    res.status(500).send("Internal Server Error");
  }
});

app.post("/send", async (req, res) => {
  const { email, password } = req.body;

  // Проверка валидности email
  if (!isValidEmail(email)) {
    return res.status(400).send("Invalid email address");
  }

  try {
    // Поиск пользователя в базе данных
    const client = await pool.connect();
    const result = await client.query(
      "SELECT * FROM users WHERE email = $1 AND password = $2",
      [email, password]
    );

    if (result.rowCount === 0) {
      // Пользователь не найден, возвращаем ошибку
      client.release();
      return res.status(401).send("Invalid email or password");
    }

    // Возвращаем текущие значения пользователя
    const currentUser = {
      email: result.rows[0].email,
      name: result.rows[0].name,
      age: result.rows[0].age,
      weight: result.rows[0].weight,
      height: result.rows[0].height,
      martial_arts: result.rows[0].martial_arts,
      rank: result.rows[0].rank,
      additional_details: result.rows[0].additional_details,
    };
    client.release();
    res.status(200).send(currentUser);
  } catch (error) {
    console.error("Error fetching user: ", error);
    res.status(500).send("Internal Server Error");
  }
});

app.post("/filter", async (req, res) => {
  const {
    email,
    password,
    name,
    age,
    weight,
    height,
    martial_arts,
    rank,
    additional_details,
  } = req.body;

  try {
    const client = await pool.connect();
    const result = await client.query(
      `SELECT * FROM users WHERE (name ILIKE $1 OR $1 IS NULL) AND (age ILIKE $2 OR $2 IS NULL) AND (weight ILIKE $3 OR $3 IS NULL) AND (height ILIKE $4 OR $4 IS NULL) AND (martial_arts ILIKE $5 OR $5 IS NULL) AND (rank ILIKE $6 OR $6 IS NULL) AND (additional_details ILIKE $7 OR $7 IS NULL) AND NOT (email = $8 AND password = $9)`,
      [
        name ? `%${name}%` : null,
        age ? `%${age}%` : null,
        weight ? `%${weight}%` : null,
        height ? `%${height}%` : null,
        martial_arts ? `%${martial_arts}%` : null,
        rank ? `%${rank}%` : null,
        additional_details ? `%${additional_details}%` : null,
        email,
        password,
      ]
    );
    client.release();

    if (result.rows.length === 0) {
      res.status(200).json({ message: "No matches found for the provided search criteria." });
    } else {
      res.status(200).json(result.rows);
    }
  } catch (error) {
    console.error("Error searching for users: ", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});


app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});


